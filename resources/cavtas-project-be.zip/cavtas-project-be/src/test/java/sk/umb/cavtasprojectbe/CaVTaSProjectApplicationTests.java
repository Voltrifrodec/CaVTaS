package sk.umb.cavtasprojectbe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaVTaSProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}

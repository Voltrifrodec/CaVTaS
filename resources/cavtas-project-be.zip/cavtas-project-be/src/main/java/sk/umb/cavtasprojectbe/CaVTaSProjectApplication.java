package sk.umb.cavtasprojectbe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaVTaSProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CaVTaSProjectApplication.class, args);
	}

}
